package com.ex.memberboard.common;

public class PagingConst {

    public static final int PAGE_LIMIT = 5; // 한 페이지에 보여줄 글 갯수
    public static final int BLOCK_LIMIT = 3; // 한 화면에 페이지 갯수

}
