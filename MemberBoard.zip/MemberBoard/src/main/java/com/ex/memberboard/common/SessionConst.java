package com.ex.memberboard.common;

public class SessionConst {

    public static final String LOGIN_ID = "loginId";
    public static final String LOGIN_EMAIL = "loginEmail";

}
